#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import math
import numpy as np
from std_msgs.msg import Bool
from puzzlebot_msgs.msg import CustomPose

class PathGenerator(Node):
    def __init__(self):
        super().__init__('path_generator')
        
        self.pose_pub = self.create_publisher(CustomPose, 'pose', 10)
        
        # Suscriptor para saber cuando el robot llego al punto
        self.sub_reached = self.create_subscription(Bool, 'goal_reached', self.reached_cb, 10)
        
        # Limites de Seguridad del Robot
        self.v_max = 0.25   
        
        self.puntos = []
        self.parametros = []
        self.mensajes_a_enviar = []
        self.punto_actual = 0
        
        self.get_logger().info('--- CONFIGURACION DE TRAYECTORIA ---')
        # El reto pide minimo 3 puntos sin contar el inicial [0,0,0]
        num_puntos = int(input("¿Cuantos puntos desea ingresar? (Minimo 3): "))
        if num_puntos < 3: num_puntos = 3

        for i in range(num_puntos):
            x = float(input(f"Punto {i+1} - Coordenada X: "))
            y = float(input(f"Punto {i+1} - Coordenada Y: "))
            v = float(input(f"Punto {i+1} - Velocidad deseada (m/s): "))
            self.puntos.append((x, y))
            self.parametros.append(v)

        print("\n--- REPORTE DE FACTIBILIDAD DINAMICA ---")
        current_x, current_y = 0.0, 0.0

        for i in range(num_puntos):
            tx, ty = self.puntos[i]
            v_deseada = self.parametros[i]
            
            dx = tx - current_x
            dy = ty - current_y
            dist = math.sqrt(dx**2 + dy**2)
            
            # Comprobacion dinamica (Robustez y reglas del reto)
            alcanzable = "Punto factible."
            if v_deseada > self.v_max:
                alcanzable = f"ADVERTENCIA: Velocidad {v_deseada} excede V_max. Se limitara a {self.v_max} m/s por seguridad."
                v_deseada = self.v_max

            print(f"Meta {i+1} -> ({tx}, {ty}) | Distancia: {dist:.2f} m | {alcanzable}")
            
            # Preparar el mensaje custom
            msg = CustomPose()
            msg.pose.position.x = tx
            msg.pose.position.y = ty
            msg.target_velocity = float(v_deseada)
            self.mensajes_a_enviar.append(msg)

            current_x, current_y = tx, ty

        # Enviar el primer punto tras iniciar
        self.get_logger().info("Iniciando trayectoria en 3 segundos...")
        self.timer = self.create_timer(3.0, self.enviar_primer_punto)

    def enviar_primer_punto(self):
        self.timer.cancel() # Cancelamos timer inicial
        self.enviar_meta_actual()

    def reached_cb(self, msg):
        if msg.data == True:
            self.punto_actual += 1
            if self.punto_actual < len(self.mensajes_a_enviar):
                self.enviar_meta_actual()
            else:
                self.get_logger().info('¡Toda la trayectoria ha sido completada con éxito!')
                raise SystemExit # Cierra el nodo automaticamente

    def enviar_meta_actual(self):
        msg = self.mensajes_a_enviar[self.punto_actual]
        self.pose_pub.publish(msg)
        self.get_logger().info(f'>> Publicando Meta {self.punto_actual + 1}: ({msg.pose.position.x}, {msg.pose.position.y})')

def main(args=None):
    rclpy.init(args=args)
    node = PathGenerator()
    try: rclpy.spin(node)
    except SystemExit: pass
    except KeyboardInterrupt: pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
