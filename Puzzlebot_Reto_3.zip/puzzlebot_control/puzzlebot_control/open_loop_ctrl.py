#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import numpy as np
import math
from std_msgs.msg import Float32
from geometry_msgs.msg import Twist
from rclpy.qos import qos_profile_sensor_data

class ClosedLoopCtrl(Node):
    def __init__(self):
        super().__init__('open_loop_ctrl')

        self.x, self.y, self.th = 0.0, 0.0, 0.0
        self.v_r, self.v_l = 0.0, 0.0
        self.r = 0.05
        self.l = 0.18
        self.last_time = self.get_clock().now()

        self.waypoints = [(2.0, 0.0), (2.0, 2.0), (0.0, 2.0), (0.0, 0.0)]
        self.current_idx = 0
        self.target_x, self.target_y = self.waypoints[0]

        # Control PID Lineal
        self.kp_v = 0.5
        self.ki_v = 0.01  
        self.kd_v = 0.1   
        self.e_dist_sum = 0.0
        self.e_dist_prev = 0.0
        self.i_windup_limit = 0.5 

        # Control P Angular
        self.kp_w = 1.4

        self.v_max = 0.25
        self.w_max = 0.7
        self.tolerance = 0.08

        self.create_subscription(Float32, 'VelocityEncR', self.vr_cb, qos_profile_sensor_data)
        self.create_subscription(Float32, 'VelocityEncL', self.vl_cb, qos_profile_sensor_data)
        
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        self.timer = self.create_timer(0.05, self.control_loop)
        
        self.get_logger().info("Trayectoria cuadrada de 2m con PID")

    def vr_cb(self, msg): 
        self.v_r = msg.data * self.r
        
    def vl_cb(self, msg): 
        self.v_l = msg.data * self.r

    def control_loop(self):
        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds / 1e9
        self.last_time = now
        
        if dt <= 0: return

        v_robot = (self.v_r + self.v_l) / 2.0
        w_robot = (self.v_r - self.v_l) / self.l
        
        self.x += v_robot * np.cos(self.th) * dt
        self.y += v_robot * np.sin(self.th) * dt
        self.th += w_robot * dt

        dx = self.target_x - self.x
        dy = self.target_y - self.y
        dist = math.sqrt(dx**2 + dy**2) 
        
        angle_to_goal = math.atan2(dy, dx)
        e_ang = math.atan2(math.sin(angle_to_goal - self.th), math.cos(angle_to_goal - self.th)) 

        if dist < self.tolerance:
            self.current_idx += 1
            self.e_dist_sum = 0.0
            self.e_dist_prev = 0.0
            
            if self.current_idx < len(self.waypoints):
                self.target_x, self.target_y = self.waypoints[self.current_idx]
                self.get_logger().info(f"Punto alcanzado. Siguiente meta: ({self.target_x}, {self.target_y})")
            else:
                self.get_logger().info("Cuadrado completado")
                self.cmd_vel_pub.publish(Twist())
                self.timer.cancel()
                return

        cmd = Twist()
        if abs(e_ang) > 0.45: 
            cmd.linear.x = 0.0
            cmd.angular.z = np.clip(self.kp_w * e_ang, -self.w_max, self.w_max)
        else:
            P = self.kp_v * dist
            self.e_dist_sum += dist * dt
            self.e_dist_sum = np.clip(self.e_dist_sum, -self.i_windup_limit, self.i_windup_limit)
            I = self.ki_v * self.e_dist_sum
            D = self.kd_v * (dist - self.e_dist_prev) / dt
            self.e_dist_prev = dist
            
            pid_v = P + I + D
            
            cmd.linear.x = np.clip(pid_v, -self.v_max, self.v_max)
            cmd.angular.z = np.clip(self.kp_w * e_ang, -self.w_max, self.w_max)

        self.cmd_vel_pub.publish(cmd)

def main(args=None):
    rclpy.init(args=args)
    node = ClosedLoopCtrl()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.cmd_vel_pub.publish(Twist())
        if rclpy.ok():
            node.destroy_node()
            rclpy.shutdown()

if __name__ == '__main__':
    main()
