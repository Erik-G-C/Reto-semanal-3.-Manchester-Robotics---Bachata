#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import numpy as np
import math
from std_msgs.msg import Float32, Bool
from geometry_msgs.msg import Twist
from rclpy.qos import qos_profile_sensor_data
from puzzlebot_msgs.msg import CustomPose

class ClosedLoopCtrl(Node):
    def __init__(self):
        super().__init__('open_loop_ctrl_2')

        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        self.goal_reached_pub = self.create_publisher(Bool, 'goal_reached', 10)
        
        self.pose_sub = self.create_subscription(CustomPose, 'pose', self.pose_callback, 10)
        self.create_subscription(Float32, 'VelocityEncR', self.vr_cb, qos_profile_sensor_data)
        self.create_subscription(Float32, 'VelocityEncL', self.vl_cb, qos_profile_sensor_data)

        self.x, self.y, self.th = 0.0, 0.0, 0.0
        self.v_r, self.v_l = 0.0, 0.0
        
        # --- CAMBIO MUY MUY POCO: De 0.18 a 0.175 ---
        self.r, self.l = 0.05, 0.175
        
        self.last_time = self.get_clock().now()

        self.has_goal = False
        self.target_x, self.target_y = 0.0, 0.0

        # --- VARIABLES ORIGINALES ---
        self.kp_v = 0.6
        self.ki_v = 0.01  
        self.kd_v = 0.15   
        self.kp_w = 1.5   
        self.w_max = 0.8  
        self.v_max = 0.25
        self.tolerance = 0.08
        self.i_windup_limit = 0.5 

        self.timer = self.create_timer(0.05, self.control_loop)
        self.get_logger().info('Controlador PID (Codigo original, ajuste minimo 0.175). Esperando metas...')

    def vr_cb(self, msg): self.v_r = msg.data * self.r
    def vl_cb(self, msg): self.v_l = msg.data * self.r

    def pose_callback(self, msg):
        self.target_x = msg.pose.position.x
        self.target_y = msg.pose.position.y
        self.v_max = msg.target_velocity 
        self.e_dist_sum = 0.0
        self.e_dist_prev = 0.0
        self.has_goal = True
        self.get_logger().info(f'Nueva meta: X: {self.target_x}, Y: {self.target_y}')

    def control_loop(self):
        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds / 1e9
        self.last_time = now
        if dt <= 0: return

        v_robot = (self.v_r + self.v_l) / 2.0
        w_robot = (self.v_r - self.v_l) / self.l
        self.x += v_robot * np.cos(self.th) * dt
        self.y += v_robot * np.sin(self.th) * dt
        self.th += w_robot * dt

        if not self.has_goal:
            return 

        dx = self.target_x - self.x
        dy = self.target_y - self.y
        dist = math.sqrt(dx**2 + dy**2)
        
        angle_to_goal = math.atan2(dy, dx)
        e_ang = math.atan2(math.sin(angle_to_goal - self.th), math.cos(angle_to_goal - self.th))

        cmd = Twist()

        if dist < self.tolerance:
            self.get_logger().info('Meta alcanzada!')
            self.cmd_vel_pub.publish(Twist()) 
            self.has_goal = False
            msg_reached = Bool()
            msg_reached.data = True
            self.goal_reached_pub.publish(msg_reached)
            return

        # Tolerancia original un poco más flexible para que no se atore
        if abs(e_ang) > 0.2: 
            cmd.linear.x = 0.0
            cmd.angular.z = np.clip(self.kp_w * e_ang, -self.w_max, self.w_max)
        else:
            P = self.kp_v * dist
            self.e_dist_sum += dist * dt
            self.e_dist_sum = np.clip(self.e_dist_sum, -self.i_windup_limit, self.i_windup_limit)
            I = self.ki_v * self.e_dist_sum
            D = self.kd_v * (dist - self.e_dist_prev) / dt
            self.e_dist_prev = dist
            
            cmd.linear.x = np.clip(P + I + D, -self.v_max, self.v_max)
            cmd.angular.z = np.clip(self.kp_w * e_ang, -self.w_max, self.w_max)

        self.cmd_vel_pub.publish(cmd)

def main(args=None):
    rclpy.init(args=args)
    node = ClosedLoopCtrl()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    finally:
        node.cmd_vel_pub.publish(Twist())
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
